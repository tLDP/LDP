/* hello-4.c - Demonstrates tainting messages and documentation.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#define DRIVER_AUTHOR "Peter Jay Salzman <p@dirac.org>"
#define DRIVER_DESC   "A sample driver"


static int __init hello4_init_function(void)
{
   printk(KERN_ALERT "Hello, world 4\n");
   return 0;
}


static void __exit hello4_cleanup_function(void)
{
   printk(KERN_ALERT "Goodbye, world 4\n");
}


module_init(hello4_init_function);
module_exit(hello4_cleanup_function);

/* You can use strings here or a define, as shown.  It doesn't matter what you
 * actually name the #define's, so "AUTHOR" is as good as "DRIVER_AUTHOR". */
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);

/* This gets rid of the "taint message" by declaring this code as GPL. */
MODULE_LICENSE("GPL");

/* This says that the module uses /dev/testdevice.  It might be used in the
 * future to help automatic configuration of modules, but is currently unused
 * other than documentation purposes. */
MODULE_SUPPORTED_DEVICE("testdevice");
