/* hello-5.c - Demonstrates command line argument passing to a module.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

static int myint = 0;
static char *mystring = "blah";

MODULE_PARM (myint, "i");
MODULE_PARM (mystring, "s");


static int __init hello5_init_function(void)
{
   printk(KERN_ALERT "Hello, world 5\n");
   printk(KERN_ALERT "integer: %i\n", myint);
   printk(KERN_ALERT "string: %s\n", mystring);
   return 0;
}


static void __exit hello5_cleanup_function(void)
{
   printk(KERN_ALERT "Goodbye, world 5\n");
}


module_init(hello5_init_function);
module_exit(hello5_cleanup_function);
