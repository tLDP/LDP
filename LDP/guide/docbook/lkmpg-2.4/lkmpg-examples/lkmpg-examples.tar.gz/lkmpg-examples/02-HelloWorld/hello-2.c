/* hello-2.c - Demonstrating the module_init() and module_exit() macros.
 */

#include <linux/module.h>   /* Needed by all modules */
#include <linux/kernel.h>   /* Needed for KERN_ALERT */
#include <linux/init.h>     /* Needed for the macros */


int my_wonderful_init(void)
{
   printk(KERN_ALERT "Hello, world 2\n");
   return 0;
}


void my_wonderful_cleanup(void)
{
   printk(KERN_ALERT "Goodbye, world 2\n");
}


module_init(my_wonderful_init);
module_exit(my_wonderful_cleanup);
