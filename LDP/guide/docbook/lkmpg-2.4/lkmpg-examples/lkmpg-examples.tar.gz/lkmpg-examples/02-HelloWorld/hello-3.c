/* hello-3.c - Illustrating the __init, __initdata and __exit macros.
 */

#include <linux/module.h>      /* Needed by all modules */
#include <linux/kernel.h>      /* Needed for KERN_ALERT */
#include <linux/init.h>        /* Needed for the macros */


static int hello3_data __initdata = 3;


static int __init hello3_init_function(void)
{
   printk(KERN_ALERT "Hello, world %d\n", hello3_data);
   return 0;
}


static void __exit hello3_cleanup_function(void)
{
   printk(KERN_ALERT "Goodbye, world 3\n");
}


module_init(hello3_init_function);
module_exit(hello3_cleanup_function);
