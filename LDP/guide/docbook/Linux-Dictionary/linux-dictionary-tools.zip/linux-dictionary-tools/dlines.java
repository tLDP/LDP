/**
 * Title:        Mr<p>
 * Description:  Puts a space between each dictionary entry
 * next.java<p>
 * Copyright:    Copyright (c) Binh Nguyen<p>
 * Company:      <p>
 * @author Binh Nguyen
 * @version 1.0
 */
import java.io.*;

public class dlines
{

   public static void main (String args[])
	throws java.io.FileNotFoundException, java.io.IOException
	{
		FileReader fr = new FileReader (new File(args[0])); 

		BufferedReader br = new BufferedReader(fr); 

		String s;

		while ((s=br.readLine())!=null)
		{
			System.out.println(s);
			System.out.println();
		}
		return;

	}

}
