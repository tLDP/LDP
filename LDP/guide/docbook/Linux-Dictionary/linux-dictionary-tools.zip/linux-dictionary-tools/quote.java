/**
 * Title:        Mr<p>
 * Description:  Program designed to quote dictionary terms
 * <p>
 * Copyright:    Copyright (c) Binh Nguyen<p>
 * Company:      <p>
 * @author Binh Nguyen
 * @version 1.0
 */
import java.io.*;

public class quote
{

   public static void main (String args[])
	throws java.io.FileNotFoundException, java.io.IOException
	{
		FileReader fr = new FileReader (new File(args[0])); 

		BufferedReader br = new BufferedReader(fr); 

		String s;
		int count=0;

		while ((s=br.readLine())!=null)
		{
				System.out.println(s + " From Somewhere");
		}
		return;

	}

}
