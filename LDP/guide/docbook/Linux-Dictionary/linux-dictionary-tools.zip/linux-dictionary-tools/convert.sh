#!/bin/bash

#Put a line between each dictionary entry
for i in `ls sort-strip-*`
do
java dlines "$i" > doubled-${i}
done

rm -f strip-*
rm -f sort-*
rm -f sort-strip-*

#Finally convert to XML
for i in `ls doubled-sort-strip-*`
do
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" >> ${i}.xml
echo "<glossary id=\"`echo "$i" | sed 's/.xml//' | sed 's/doubled-sort-strip-//'`\">" >> ${i}.xml
echo "<title>`echo "$i" | sed 's/.xml//' | sed 's/doubled-sort-strip-//'`</title>"  >> ${i}.xml
echo "" >> ${i}.xml
grep . "$i" | awk 'BEGIN { FS="\t" } { print "<glossentry>\n<glossterm>\n" $1 \
"\n</glossterm>\n<glossdef>\n<para>\n" $2 "\n<ulink url=\"http://www.tldp.org/LDP/Linux-Dictionary/\">http://www.tldp.org/LDP/Linux-Dictionary/</ulink>\n</para>\n</glossdef>\n</glossentry>\n" }' >> ${i}.xml
echo "</glossary>" >> ${i}.xml
done
