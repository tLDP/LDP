#!/bin/bash

for i in `ls *.xml`
do
java strip "$i" > strip-${i}
done
