#include <stdio.h>

/* This program encodes a file with the relevant character entities ready
 * for conversion to XML. It is distributed under the GPL License.
 * Binh Nguyen, June 2003
*/

int main (void)
{
	char ch='0';

	while ((ch=getchar())!=EOF)
	{
		if (ch=='<') printf("&lt;");
		else if (ch=='>') printf("&gt;");
		else if (ch=='&') printf("&amp;");
		else if (ch=='\'') printf("&apos;");
		else if (ch=='\"') printf("&quot;");
		else printf("%c", ch);	
	}

}	
