#!/bin/bash

for i in `ls [A-Z] Punctuation`
do
java quote "$i" > quote-${i}
done
