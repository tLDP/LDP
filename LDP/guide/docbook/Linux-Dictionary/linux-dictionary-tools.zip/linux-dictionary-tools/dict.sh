#!/bin/bash

VERSION="0.18"

for i in `ls Punctuation.xml [A-Z].xml`
do
java dict "$i" > dict-${i}
done

cat dict-Punctuation* > linux-dictionary.flat

for i in `ls dict-[A-Z]*`
do
cat "$i" >> linux-dictionary.flat
rm -f "$i"
done

cat license > license-linux-dictionary.flat
cat linux-dictionary.flat >> license-linux-dictionary.flat
mv -f license-linux-dictionary.flat linux-dictionary.flat

fmt -w 80 linux-dictionary.flat > linux-dictionary.fmt
rm -f linux-dictionary.flat
./dictfmt -f -u "http://www.tldp.org/LDP/Linux-Dictionary/" -s "Linux-Dictionary $VERSION" ./linux-dictionary < linux-dictionary.fmt
rm -f linux-dictionary.fmt
dictzip linux-dictionary.dict
tar cvf dict-linux-dictionary.tar linux-dictionary.dict.dz linux-dictionary.index
rm -f dict-linux-dictionary.tar.bz2
bzip2 dict-linux-dictionary.tar
