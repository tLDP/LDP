#!/bin/bash

for i in `ls strip-*.xml`
do
sort -f "$i" > sort-${i}
done
