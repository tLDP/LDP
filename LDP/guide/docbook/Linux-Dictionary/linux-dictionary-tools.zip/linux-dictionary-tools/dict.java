/**
 * Title:        Mr<p>
 * Description:  
 * <p>
 * Copyright:    Copyright (c) Binh Nguyen<p>
 * Company:      <p>
 * @author Binh Nguyen
 * @version 1.0
 */
import java.io.*;

/* NB - This program is designed to specifically to strip the
 * Linux Dictionary of XML tags and convert it to a form that
 * is necessary for use with the dictd dictionary server.
*/

public class dict
{

   public static void main (String args[])
	throws java.io.FileNotFoundException, java.io.IOException
	{
		FileReader fr = new FileReader (new File(args[0])); 

		BufferedReader br = new BufferedReader(fr); 

		String s;
		int count=0;

		while ((s=br.readLine())!=null)
		{

			if (s.startsWith("<glossterm>")) 
			{
				count=1;
				continue;	
			}
			else if (count==1)
			{
				System.out.println(s);
				count=0;
				continue;
			}
			else if (s.startsWith("<para>")) 
			{
				count=2;
				continue;	
			}
			else if (count==2)
			{
				System.out.println("        " + s + " http://www.tldp.org/LDP/Linux-Dictionary/");
				System.out.println("       ");
				System.out.println();
				count=0;
				continue;
			}
			else
			{
				continue;
			}
		}
		return;

	}

}
