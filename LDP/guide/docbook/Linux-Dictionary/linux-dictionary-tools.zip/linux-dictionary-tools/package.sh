#! /bin/sh

VERSION="0.18-0"

fakeroot dpkg-deb --build debian
mv -f debian.deb "dict-linux-dictionary-$VERSION.deb"
alien --to-rpm --to-slp --to-lsb --to-tgz "dict-linux-dictionary-$VERSION.deb"
