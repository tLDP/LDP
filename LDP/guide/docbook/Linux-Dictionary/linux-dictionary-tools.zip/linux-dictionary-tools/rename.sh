#!/bin/bash

for i in `ls doubled-sort-strip-*.xml.xml`
do
mv -f "$i" `echo "$i" | sed 's/.xml.xml/.xml/' | sed 's/doubled-sort-strip-//'`
done
